Build the course project report

Main file: RL_Project_Report_IEEE.tex
Tested compiler: Tectonic 0.17.0 (XeTeX-based)

Extract this ZIP to a folder and run:
    tectonic RL_Project_Report_IEEE.tex

The package includes the class files, figures and an embedded bibliography.
The verified output has 18 pages. IEEE Access formatting is used for the course
report; this is an unpublished academic project.

The supplied Access class has a XeTeX colour-compatibility adjustment and course
metadata in place of publication placeholders. Its notices are retained.

For the newer dispatch learner, training return is negative full cost divided
by episode days. The checkpoint curve uses negative cost/3. The base-equivalent
return table uses negative full cost. Both are derived from the saved costs.

Some evaluation endpoints are retrospective, as explained in the report.
The text distinguishes measured results, illustrative arithmetic and future work.
