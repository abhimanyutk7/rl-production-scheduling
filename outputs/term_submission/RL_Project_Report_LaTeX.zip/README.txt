RL production scheduling academic report

Main source: RL_Project_Report_IEEE.tex
Compiled report: exactly 18 pages.
Tested compiler: Tectonic 0.17.0 (XeTeX-based).
Run: tectonic RL_Project_Report_IEEE.tex
All required class files and figures are included. Bibliography is embedded in the main source.

The supplied IEEE Access class and IEEEtran base class provide formatting. The local Access class uses the same CMYK blue instead of pdfTeX-only spot-colour commands for XeTeX compatibility. Publication placeholder metadata is replaced with an unpublished academic project label and course footer. This is not an IEEE publication.

Processing times are benchmark-derived and other factory dynamics are synthetic. Evaluation examples from PPTperfromance.pdf are not project measurements. Final selected-policy episode success is a retrospective descriptive endpoint. Regret to an optimal policy, controlled sample efficiency and broad matched DQN robustness are not claimed.

Final submission clarification (8 November 2026): newer dispatch PPO rewards are divided by episode days. Training curves use negative cost/3; the base-equivalent return table uses negative full cost. Cost results are unchanged.
